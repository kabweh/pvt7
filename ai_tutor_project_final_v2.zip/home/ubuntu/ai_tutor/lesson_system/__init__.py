"""
__init__.py file for lesson_system package.
Makes the package importable and exposes key classes.
"""
from .lesson_explainer import LessonExplainer
from .explanation_component import ExplanationComponent

__all__ = ['LessonExplainer', 'ExplanationComponent']

"""
__init__.py file for tests package.
Makes the package importable.
"""
# This file intentionally left empty to make the tests directory a Python package
